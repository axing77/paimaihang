Auctionator.FullScan.Events = {
  ScanStart = "replicate_scan_start",
  ScanProgress = "replicate_scan_progress",
  ScanComplete = "replicate_scan_complete",
  ScanFailed = "replicate_scan_failed",
}

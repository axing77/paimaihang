Auctionator.Search.Events = {
  PricesProcessed = "search_prices_processed",
}

Auctionator.Buying = {}

Auctionator.Buying.Events = {
  ShowForShopping = "buying_show_for_shopping",
  ViewSetup = "buying_view_setup",
  AuctionFocussed = "buying_auction_focussed",
  StacksUpdated = "buying_stacks_updated",
  HistoricalPrice = "buying_historical_price",
}

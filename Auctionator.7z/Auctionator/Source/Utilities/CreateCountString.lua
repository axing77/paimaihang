function Auctionator.Utilities.CreateCountString(count)
    return LIGHTBLUE_FONT_COLOR:WrapTextInColorCode(" x" .. count)
end

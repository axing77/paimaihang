Auctionator.Buying = {}
Auctionator.Buying.Events = {
  ShowItemBuy = "buy show item",
  ShowItemConfirmation = "buy show item confirmation",
  RefreshingItems = "buy refreshing items",

  ShowCommodityBuy = "buy show commodity",
  SelectCommodityRow = "buy select commodity row",
  RefreshingCommodities = "buy refreshing commodities",
}

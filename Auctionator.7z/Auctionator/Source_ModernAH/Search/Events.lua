Auctionator.Search.Events = {
  SearchResultsReady = "SEARCH_RESULTS_READY",
  BlizzardInfo = "BLIZZARD_INFO"
}

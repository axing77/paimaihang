Auctionator.EnchantInfo = {}

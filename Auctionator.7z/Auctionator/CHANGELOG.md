# Auctionator

## [284](https://github.com/Auctionator/Auctionator/tree/284) (2025-07-18)
[Full Changelog](https://github.com/Auctionator/Auctionator/compare/283...284) 

- Fix CBOR serialization on logout  
- Rework price database storage to use CBOR serialization on logout  

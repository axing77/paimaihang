Auctionator.Config.Options.PROSPECT_TOOLTIPS = "prospect_tooltips"
Auctionator.Config.Options.MILL_TOOLTIPS = "mill_tooltips"

Auctionator.Config.Defaults[Auctionator.Config.Options.PROSPECT_TOOLTIPS] = false
Auctionator.Config.Defaults[Auctionator.Config.Options.MILL_TOOLTIPS] = false
